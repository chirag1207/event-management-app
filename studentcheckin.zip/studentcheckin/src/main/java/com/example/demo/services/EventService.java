package com.example.demo.services;

import com.example.demo.models.Event;
import com.example.demo.repository.EventRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EventService {

    @Autowired
    private EventRepository eventRepository;

    /**
     * Save a new event or update an existing event.
     * 
     * @param event the event to be saved
     * @return the saved event
     */
    public Event saveEvent(Event event) {
        return eventRepository.save(event);
    }

    /**
     * Get an event by its ID.
     * 
     * @param eventId the ID of the event
     * @return an Optional containing the event if found, otherwise empty
     */
    public Optional<Event> getEventById(Long eventId) {
        return eventRepository.findById(eventId);
    }

    /**
     * Get all events.
     * 
     * @return a list of all events
     */
    public List<Event> getAllEvents() {
        return eventRepository.findAll();
    }

    /**
     * Delete an event by its ID.
     * 
     * @param eventId the ID of the event to be deleted
     * @return a ResponseEntity indicating the result of the delete operation
     */
    public ResponseEntity<String> deleteEvent(Long eventId) {
        try {
            eventRepository.deleteById(eventId);
            return ResponseEntity.ok("Event deleted successfully");
        } catch (EmptyResultDataAccessException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Event not found");
        }
    }
}
