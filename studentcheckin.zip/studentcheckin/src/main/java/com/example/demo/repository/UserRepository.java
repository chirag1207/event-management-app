package com.example.demo.repository;

import org.springframework.stereotype.Repository;
import com.example.demo.models.User;
import jakarta.transaction.Transactional;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    @Query(value = "SELECT email FROM users WHERE email = :email", nativeQuery = true)
    List<String> checkUserEmail(@Param("email") String email);

    @Query(value = "SELECT password FROM users WHERE email = :email", nativeQuery = true)
    String checkUserPasswordByEmail(@Param("email") String email);

    @Query(value = "SELECT * FROM users WHERE email = :email", nativeQuery = true)
    User getUserDetailsByEmail(@Param("email") String email);

    @Transactional
    @Modifying
    @Query(value = "INSERT INTO users (full_name, dob, height, weight, email, password, phone, street_name, city, state, pincode) " +
                   "VALUES (:full_name, :dob, :height, :weight, :email, :password, :phone, :street_name, :city, :state, :pincode)", nativeQuery = true)
    int registerNewUser(@Param("full_name") String full_name,
                        @Param("dob") String dob,
                        @Param("height") Integer height,
                        @Param("weight") Integer weight,
                        @Param("email") String email,
                        @Param("password") String password,
                        @Param("phone") String phone,
                        @Param("street_name") String street_name,
                        @Param("city") String city,
                        @Param("state") String state,
                        @Param("pincode") Integer pincode);

	User findByEmail(String email);
    
    
   

}
