package com.example.demo.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.models.Event;
import com.example.demo.models.EventSchedule;
import com.example.demo.models.EventScheduleDTO;
import com.example.demo.repository.EventScheduleRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class EventScheduleService {

    @Autowired
    private EventScheduleRepository eventScheduleRepository;

    public List<EventScheduleDTO> getEventSchedulesByDate(LocalDate date) {
        List<EventSchedule> eventSchedules = eventScheduleRepository.findByEventDate(date);
        return eventSchedules.stream()
                .map(eventSchedule -> {
                    Event event = eventSchedule.getEvent();
                    return new EventScheduleDTO(
                        event != null ? event.getName() : "No Event Name",
                        event != null ? event.getDetails() : "No Event Details",
                        eventSchedule.getEventTime().toString() // Adjust format if needed
                    );
                })
                .collect(Collectors.toList());
    }
}
