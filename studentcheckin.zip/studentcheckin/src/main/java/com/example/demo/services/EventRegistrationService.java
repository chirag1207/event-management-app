package com.example.demo.services;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.models.EventRegistration;
import com.example.demo.repository.EventRegistrationRepository;

import java.util.List;

@Service
public class EventRegistrationService {

    @Autowired
    private EventRegistrationRepository repository;

    public EventRegistration saveRegistration(EventRegistration registration) {
    	   if (isAlreadyRegistered(registration.getUserId(), registration.getEventId())) {
               return null; // Return null or throw an exception
           }
           return repository.save(registration);
       }

    public List<EventRegistration> getEventsByUserId(String userId) {
        return repository.findByUserId(userId);
    }
    private boolean isAlreadyRegistered(String userId, String eventId) {
        // Implement logic to check if registration exists
        return repository.existsByUserIdAndEventId(userId, eventId);
    }
}
