package com.example.demo.services;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.models.User;
import com.example.demo.repository.UserRepository;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public int registerNewUser(String full_name, String dob, Integer height, Integer weight, String email, String password, String phone, String street_name, String city, String state, Integer pincode) {
        return userRepository.registerNewUser(full_name, dob, height, weight, email, password, phone, street_name, city, state, pincode);
    }

    public List<String> checkUserEmail(String email) {
        return userRepository.checkUserEmail(email);
    }

    public String checkUserPasswordByEmail(String email) {
        return userRepository.checkUserPasswordByEmail(email);
    }

    public User getUserDetailsByEmail(String email) {
        return userRepository.getUserDetailsByEmail(email);
    }
    
    public User getUserDetailsById(Long id) {
        return userRepository.findById(id).orElse(null);
    }
    
    public User updateUserInfo(Long userId, User userDetails) {
        return userRepository.findById(userId).map(user -> {
            user.setFullName(userDetails.getFullName());
            user.setDob(userDetails.getDob());
            user.setHeight(userDetails.getHeight());
            user.setWeight(userDetails.getWeight());
            user.setEmail(userDetails.getEmail());
            user.setPassword(userDetails.getPassword());
            user.setPhone(userDetails.getPhone());
            user.setStreetName(userDetails.getStreetName());
            user.setCity(userDetails.getCity());
            user.setState(userDetails.getState());
            user.setPincode(userDetails.getPincode());
            return userRepository.save(user);
        }).orElse(null);
    }

    public boolean isEmailRegistered(String email) {
        // Check if the user with the given email exists in the database
        return userRepository.findByEmail(email) != null; // Assuming UserRepository has findByEmail method
    }
    
}
