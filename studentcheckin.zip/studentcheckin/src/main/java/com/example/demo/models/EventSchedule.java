package com.example.demo.models;


import jakarta.persistence.*;

@Entity
@Table(name = "event_schedule")
public class EventSchedule {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "event_id", nullable = false)
    private Event event;

    @Column(name = "event_date", nullable = false)
    private java.sql.Date eventDate;

    @Column(name = "event_time", nullable = false)
    private java.sql.Time eventTime;

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Event getEvent() {
        return event;
    }

    public void setEvent(Event event) {
        this.event = event;
    }

    public java.sql.Date getEventDate() {
        return eventDate;
    }

    public void setEventDate(java.sql.Date eventDate) {
        this.eventDate = eventDate;
    }

    public java.sql.Time getEventTime() {
        return eventTime;
    }

    public void setEventTime(java.sql.Time eventTime) {
        this.eventTime = eventTime;
    }
}
