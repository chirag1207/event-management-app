package com.example.demo.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.services.UserService;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/v1")
public class RegisterApiController {
	
	@Autowired
	UserService userService;
	
//	@CrossOrigin(origins = "http://192.168.1.175:3000")
	@PostMapping("/user/register")
	public ResponseEntity<Map<String, String>> registerNewUser(
			@RequestParam("full_name") String full_name,
			@RequestParam("dob") String dob,
			@RequestParam("height") Integer height,
			@RequestParam("weight") Integer weight,
			@RequestParam("email") String email,
			@RequestParam("password") String password,
			@RequestParam("phone") String phone,
			@RequestParam("street_name") String street_name,
			@RequestParam("city") String city,
			@RequestParam("state") String state,
			@RequestParam("pincode") Integer pincode) {
		
		Map<String, String> response = new HashMap<>();

		if(full_name.isEmpty() || dob.isEmpty() || email.isEmpty() || password.isEmpty() || street_name.isEmpty() || city.isEmpty() || phone.isEmpty()) {
			response.put("message", "Please complete all fields.");
			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
		}
		
		 if (userService.isEmailRegistered(email)) {
		        response.put("message", "Email already in use.");
		        return new ResponseEntity<>(response, HttpStatus.CONFLICT);
		    }
		
		int result = userService.registerNewUser(full_name, dob, height, weight, email, password, phone, street_name, state, city, pincode);
		if (result != 1) {
			response.put("message", "Failed to register user.");
			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
		}
		
		response.put("message", "User Registered");
		return new ResponseEntity<>(response, HttpStatus.OK);
	}
}
