package com.example.demo.controllers;

import com.example.demo.models.Login;
import com.example.demo.models.User;
import com.example.demo.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Collections;
import java.util.List;

@RestController
@RequestMapping("/api/v1/user")
public class LoginApiController {

    @Autowired
    private UserService userService;

    @PostMapping("/login")
    public ResponseEntity<?> authenticateUser(@RequestBody Login login) {
        List<String> userEmail = userService.checkUserEmail(login.getEmail());

        if (userEmail == null || userEmail.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Collections.singletonMap("message", "Email does not exist"));
        }

        String password = userService.checkUserPasswordByEmail(login.getEmail());
        if (password == null || !password.equals(login.getPassword())) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Collections.singletonMap("message", "Incorrect password"));
        }

        User user = userService.getUserDetailsByEmail(login.getEmail());
        return ResponseEntity.ok(user);
    }
}