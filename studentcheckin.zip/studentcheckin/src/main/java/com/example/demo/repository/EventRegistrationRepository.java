package com.example.demo.repository;

import com.example.demo.models.EventRegistration;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface EventRegistrationRepository extends JpaRepository<EventRegistration, Long> {
    List<EventRegistration> findByUserId(String userId);
    
    // Custom method to check if a registration exists
    boolean existsByUserIdAndEventId(String userId, String eventId);
}

