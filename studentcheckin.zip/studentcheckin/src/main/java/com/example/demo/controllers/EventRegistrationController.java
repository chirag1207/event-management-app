package com.example.demo.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.models.EventRegistration;
import com.example.demo.services.EventRegistrationService;

import java.util.List;

@RestController
@RequestMapping("/api/registrations")
public class EventRegistrationController {

    @Autowired
    private EventRegistrationService service;

    @PostMapping
    public ResponseEntity<EventRegistration> registerEvent(@RequestBody EventRegistration registration) {
        EventRegistration savedRegistration = service.saveRegistration(registration);
        if (savedRegistration == null) {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .body(null); // Or return a custom error message
        }
        return ResponseEntity.status(HttpStatus.CREATED).body(savedRegistration);
    }

    @GetMapping("/user/{userId}")
    public List<EventRegistration> getEventsByUserId(@PathVariable String userId) {
        return service.getEventsByUserId(userId);
    }
}
