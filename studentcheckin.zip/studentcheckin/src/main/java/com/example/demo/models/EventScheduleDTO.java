package com.example.demo.models;

public class EventScheduleDTO {
    private String eventName;
    private String eventDetail;
    private String eventTime;

    public EventScheduleDTO(String eventName, String eventDetail, String eventTime) {
        this.eventName = eventName;
        this.eventDetail = eventDetail;
        this.eventTime = eventTime;
    }

    // Getters and Setters
    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public String getEventDetail() {
        return eventDetail;
    }

    public void setEventDetail(String eventDetail) {
        this.eventDetail = eventDetail;
    }

    public String getEventTime() {
        return eventTime;
    }

    public void setEventTime(String eventTime) {
        this.eventTime = eventTime;
    }
}
